#!/bin/bash

set -e

# Color codes for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m'

# Get script directory for relative paths
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
BASE_DIR="$(cd "${SCRIPT_DIR}/.." && pwd)"
TERRAFORM_DIR="${BASE_DIR}/infrastructure/terraform"
ENV_DIR="${TERRAFORM_DIR}/environments/${DEPLOY_ENV}"

# Load environment variables
if [ -z "$ENV_FILE" ]; then
    echo -e "${RED}Error: ENV_FILE not set${NC}"
    exit 1
fi

source "$ENV_FILE"

# Deploy database infrastructure
deploy_database() {
    echo -e "${YELLOW}Deploying database infrastructure...${NC}"
    
    cd "${ENV_DIR}"
    
    # Initialize Terraform for RDS
    terraform init \
        -backend-config="bucket=${TF_STATE_BUCKET}" \
        -backend-config="key=${DEPLOY_ENV}/rds/terraform.tfstate" \
        -backend-config="region=${AWS_REGION}"
    
    # Plan and apply RDS infrastructure
    terraform plan -target=module.rds -out=rds.tfplan
    terraform apply rds.tfplan
    
    echo -e "${GREEN}Database infrastructure deployed successfully${NC}"
}

# Configure database security
configure_db_security() {
    echo -e "${YELLOW}Configuring database security...${NC}"
    
    # Get DB security group ID
    DB_SG_ID=$(aws rds describe-db-instances \
        --db-instance-identifier "${DB_INSTANCE_NAME}" \
        --query 'DBInstances[0].VpcSecurityGroups[0].VpcSecurityGroupId' \
        --output text)
    
    # Update security group rules
    aws ec2 authorize-security-group-ingress \
        --group-id "${DB_SG_ID}" \
        --protocol tcp \
        --port "${DB_PORT}" \
        --source-group "${EKS_SG_ID}"
}

# Setup database backups
setup_backups() {
    echo -e "${YELLOW}Setting up database backups...${NC}"
    
    # Configure automated backups
    aws rds modify-db-instance \
        --db-instance-identifier "${DB_INSTANCE_NAME}" \
        --backup-retention-period 7 \
        --preferred-backup-window "03:00-04:00" \
        --apply-immediately
}

# Validate database setup
validate_database() {
    echo -e "${YELLOW}Validating database setup...${NC}"
    
    # Check database status
    DB_STATUS=$(aws rds describe-db-instances \
        --db-instance-identifier "${DB_INSTANCE_NAME}" \
        --query 'DBInstances[0].DBInstanceStatus' \
        --output text)
    
    if [ "$DB_STATUS" != "available" ]; then
        echo -e "${RED}Error: Database is not available${NC}"
        exit 1
    fi
    
    echo -e "${GREEN}Database validation completed${NC}"
}

# Main execution
main() {
    deploy_database
    configure_db_security
    setup_backups
    validate_database
}

main
