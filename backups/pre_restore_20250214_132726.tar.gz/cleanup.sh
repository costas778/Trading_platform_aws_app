#!/bin/bash

# Color codes for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m'

echo -e "${YELLOW}Starting force cleanup...${NC}"

# Get the absolute path to the terraform directory
TERRAFORM_DIR="/home/costas778/abc/trading-platform/infrastructure/terraform/environments/dev"

# Create temporary working directory with shorter path
TEMP_DIR="/tmp/tf_cleanup_$$"
mkdir -p "$TEMP_DIR"

# Move to temp directory to avoid path length issues
cd "$TEMP_DIR" || exit 1

# Try multiple methods to remove the problematic directory
echo -e "${YELLOW}Attempting to remove problematic directories...${NC}"

# Method 1: Using find with -delete from temp location
find "$TERRAFORM_DIR/.terraform" -delete 2>/dev/null || true

# Method 2: Using perl to handle long paths
perl -e 'use File::Path qw(remove_tree); remove_tree("'"$TERRAFORM_DIR/.terraform"'");' 2>/dev/null || true

# Method 3: Force remove any remaining terraform directories
rm -rf "$TERRAFORM_DIR"/.terraform* 2>/dev/null || true

# Clean up temporary files and directories
echo -e "${YELLOW}Cleaning up temporary files...${NC}"
cd /
rm -rf "$TEMP_DIR"
rm -rf /tmp/terraform-*
rm -rf /tmp/tf_*

# Remove terraform lock file
rm -f "$TERRAFORM_DIR"/.terraform.lock.hcl

echo -e "${GREEN}Force cleanup completed${NC}"
