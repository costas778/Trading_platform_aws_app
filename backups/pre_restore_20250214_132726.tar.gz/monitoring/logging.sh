#!/bin/bash

set -e

# Color codes for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m'

# Get script directory for relative paths
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
BASE_DIR="$(cd "${SCRIPT_DIR}/.." && pwd)"
CONFIG_DIR="${BASE_DIR}/config"
K8S_DIR="${BASE_DIR}/k8s"

# Load environment variables
if [ -z "$ENV_FILE" ]; then
    echo -e "${RED}Error: ENV_FILE not set${NC}"
    exit 1
fi

source "$ENV_FILE"

# Setup log groups
setup_log_groups() {
    echo -e "${YELLOW}Setting up CloudWatch log groups...${NC}"
    
    # Create log groups with retention
    aws logs create-log-group \
        --log-group-name "/${DEPLOY_ENV}/application" \
        --tags Environment="${DEPLOY_ENV}"
    
    aws logs put-retention-policy \
        --log-group-name "/${DEPLOY_ENV}/application" \
        --retention-in-days 30
    
    aws logs create-log-group \
        --log-group-name "/${DEPLOY_ENV}/system" \
        --tags Environment="${DEPLOY_ENV}"
    
    aws logs put-retention-policy \
        --log-group-name "/${DEPLOY_ENV}/system" \
        --retention-in-days 30
}

# Configure Fluentd
setup_fluentd() {
    echo -e "${YELLOW}Setting up Fluentd...${NC}"
    
    # Create Fluentd ConfigMap
    kubectl create configmap fluentd-config \
        --from-file="${CONFIG_DIR}/fluentd.conf" \
        -n logging \
        --dry-run=client -o yaml | kubectl apply -f -
    
    # Deploy Fluentd DaemonSet
    kubectl apply -f "${K8S_DIR}/base/fluentd-daemonset.yaml"
}

# Setup log metrics and filters
setup_log_metrics() {
    echo -e "${YELLOW}Setting up log metrics...${NC}"
    
    # Create metric filter for errors
    aws logs put-metric-filter \
        --log-group-name "/${DEPLOY_ENV}/application" \
        --filter-name "ErrorCount" \
        --filter-pattern "ERROR" \
        --metric-transformations \
            metricName=ApplicationErrors,\
            metricNamespace="${DEPLOY_ENV}/Logs",\
            metricValue=1
}

# Setup log insights queries
setup_log_insights() {
    echo -e "${YELLOW}Setting up CloudWatch Logs Insights queries...${NC}"
    
    # Save common queries
    aws cloudwatch put-dashboard \
        --dashboard-name "${DEPLOY_ENV}-logs-insights" \
        --dashboard-body "file://${CONFIG_DIR}/logs-insights-dashboard.json"
}

# Validate logging setup
validate_logging() {
    echo -e "${YELLOW}Validating logging setup...${NC}"
    
    # Check log groups
    aws logs describe-log-groups \
        --log-group-name-prefix "/${DEPLOY_ENV}" || {
        echo -e "${RED}Error: Log groups not properly configured${NC}"
        exit 1
    }
    
    # Check Fluentd status
    kubectl get ds -n logging fluentd || {
        echo -e "${RED}Error: Fluentd not running${NC}"
        exit 1
    }
    
    echo -e "${GREEN}Logging validation completed${NC}"
}

# Main execution
main() {
    setup_log_groups
    setup_fluentd
    setup_log_metrics
    setup_log_insights
    validate_logging
}

main
