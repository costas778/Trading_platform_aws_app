#!/bin/bash

set -e

# Color codes for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m'

# Load environment variables
if [ -z "$ENV_FILE" ]; then
    echo -e "${RED}Error: ENV_FILE not set${NC}"
    exit 1
fi

source "$ENV_FILE"

# Setup CloudWatch agent
setup_cloudwatch_agent() {
    echo -e "${YELLOW}Setting up CloudWatch agent...${NC}"
    
    # Create CloudWatch agent configuration
    cat > cwagent-config.json <<EOF
{
    "agent": {
        "metrics_collection_interval": 60
    },
    "metrics": {
        "metrics_collected": {
            "cpu": {
                "measurement": ["cpu_usage_idle", "cpu_usage_user", "cpu_usage_system"]
            },
            "memory": {
                "measurement": ["mem_used_percent"]
            },
            "disk": {
                "measurement": ["disk_used_percent"],
                "resources": ["/"]
            }
        },
        "append_dimensions": {
            "InstanceId": "\${aws:InstanceId}",
            "Environment": "${DEPLOY_ENV}"
        }
    }
}
EOF

    # Store CloudWatch agent configuration in SSM
    aws ssm put-parameter \
        --name "/${DEPLOY_ENV}/cloudwatch/agent-config" \
        --type String \
        --value file://cwagent-config.json \
        --overwrite
}

# Setup CloudWatch alarms
setup_alarms() {
    echo -e "${YELLOW}Setting up CloudWatch alarms...${NC}"
    
    # CPU utilization alarm
    aws cloudwatch put-metric-alarm \
        --alarm-name "${DEPLOY_ENV}-high-cpu" \
        --alarm-description "CPU utilization exceeded 80%" \
        --metric-name CPUUtilization \
        --namespace AWS/EKS \
        --statistic Average \
        --period 300 \
        --threshold 80 \
        --comparison-operator GreaterThanThreshold \
        --evaluation-periods 2 \
        --alarm-actions "${SNS_TOPIC_ARN}"

    # Memory utilization alarm
    aws cloudwatch put-metric-alarm \
        --alarm-name "${DEPLOY_ENV}-high-memory" \
        --alarm-description "Memory utilization exceeded 80%" \
        --metric-name memory_used_percent \
        --namespace CWAgent \
        --statistic Average \
        --period 300 \
        --threshold 80 \
        --comparison-operator GreaterThanThreshold \
        --evaluation-periods 2 \
        --alarm-actions "${SNS_TOPIC_ARN}"
}

# Setup Container Insights
setup_container_insights() {
    echo -e "${YELLOW}Setting up Container Insights...${NC}"
    
    # Enable Container Insights on EKS cluster
    kubectl apply -f https://raw.githubusercontent.com/aws-samples/amazon-cloudwatch-container-insights/latest/k8s-deployment-manifest-templates/deployment-mode/daemonset/container-insights-monitoring/quickstart/cwagent-fluentd-quickstart.yaml

    # Wait for Container Insights to be ready
    kubectl rollout status ds/cloudwatch-agent -n amazon-cloudwatch
    kubectl rollout status ds/fluentd-cloudwatch -n amazon-cloudwatch
}

# Setup custom metrics
setup_custom_metrics() {
    echo -e "${YELLOW}Setting up custom metrics...${NC}"
    
    # Create custom namespace
    aws cloudwatch put-metric-data \
        --namespace "${DEPLOY_ENV}/CustomMetrics" \
        --metric-name HealthCheck \
        --value 1 \
        --dimensions Service=Trading
}

# Validate monitoring setup
validate_monitoring() {
    echo -e "${YELLOW}Validating monitoring setup...${NC}"
    
    # Check CloudWatch agent status
    kubectl get daemonset cloudwatch-agent -n amazon-cloudwatch || {
        echo -e "${RED}Error: CloudWatch agent not running${NC}"
        exit 1
    }
    
    # Check alarms
    aws cloudwatch describe-alarms \
        --alarm-names "${DEPLOY_ENV}-high-cpu" "${DEPLOY_ENV}-high-memory" || {
        echo -e "${RED}Error: Alarms not properly configured${NC}"
        exit 1
    }
    
    echo -e "${GREEN}Monitoring validation completed${NC}"
}

# Main execution
main() {
    setup_cloudwatch_agent
    setup_alarms
    setup_container_insights
    setup_custom_metrics
    validate_monitoring
}

main
