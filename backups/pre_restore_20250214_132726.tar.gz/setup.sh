#!/bin/bash

# Color codes for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m'

echo -e "${YELLOW}Starting infrastructure setup...${NC}"

# Create the directory structure
mkdir -p config
mkdir -p deployment
mkdir -p docker/{frontend,backend,axon-server}
mkdir -p infrastructure/terraform/environments/{dev,staging,prod}
mkdir -p infrastructure/terraform/modules/{cloudwatch,eks,iam,networking,rds,s3,security_groups,vpc,alb,kms,ecr,secrets}
mkdir -p k8s/base/{frontend,backend-services,axon-server,database}
mkdir -p k8s/overlays/{dev,staging,prod}
mkdir -p monitoring/{prometheus,grafana}
mkdir -p security/{certificates,policies}
mkdir -p docs/{architecture,runbooks,disaster-recovery}

# Create .env file
cat << 'EOF' > .env
# Environment
DEPLOY_ENV=dev
AWS_REGION=us-east-1
AWS_ACCOUNT_ID=767397825841

# Application
DOMAIN_NAME=
HOSTED_ZONE_ID=
BUILD_VERSION=1.0.0

# Database
DB_USERNAME=admin
DB_PASSWORD=Harvee777

# Cluster
CLUSTER_NAME="dev-eks-abc"

# Microservices
MICROSERVICES="frontend backend axon-server"

# AWS Resources
TF_STATE_BUCKET=767397825841-terraform-state
KMS_KEY_ALIAS=abc-trading-key
ECR_REPOSITORY_PREFIX=abc-trading

# Monitoring
PROMETHEUS_RETENTION=15d
GRAFANA_ADMIN_PASSWORD=admin

# Security
SSL_CERT_ARN=
EOF

# Function to create ALB module
create_alb_module() {
    cat << 'EOF' > infrastructure/terraform/modules/alb/main.tf
resource "aws_lb" "main" {
  name               = "${var.project_name}-${var.environment}-alb"
  internal           = false
  load_balancer_type = "application"
  security_groups    = var.security_group_ids
  subnets           = var.subnet_ids

  tags = {
    Name        = "${var.project_name}-${var.environment}-alb"
    Environment = var.environment
  }
}

resource "aws_lb_listener" "https" {
  load_balancer_arn = aws_lb.main.arn
  port              = "443"
  protocol          = "HTTPS"
  ssl_policy        = "ELBSecurityPolicy-2016-08"
  certificate_arn   = var.certificate_arn

  default_action {
    type = "fixed-response"
    fixed_response {
      content_type = "text/plain"
      message_body = "No routes defined"
      status_code  = "404"
    }
  }
}
EOF

    cat << 'EOF' > infrastructure/terraform/modules/alb/variables.tf
variable "project_name" {
  description = "Name of the project"
  type        = string
}

variable "environment" {
  description = "Environment (dev/staging/prod)"
  type        = string
}

variable "security_group_ids" {
  description = "Security group IDs for the ALB"
  type        = list(string)
}

variable "subnet_ids" {
  description = "Subnet IDs where the ALB will be deployed"
  type        = list(string)
}

variable "certificate_arn" {
  description = "ARN of the SSL certificate"
  type        = string
}
EOF

    cat << 'EOF' > infrastructure/terraform/modules/alb/outputs.tf
output "alb_arn" {
  description = "ARN of the ALB"
  value       = aws_lb.main.arn
}

output "alb_dns_name" {
  description = "DNS name of the ALB"
  value       = aws_lb.main.dns_name
}

output "https_listener_arn" {
  description = "ARN of the HTTPS listener"
  value       = aws_lb_listener.https.arn
}
EOF
}

# Function to create KMS module
create_kms_module() {
    cat << 'EOF' > infrastructure/terraform/modules/kms/main.tf
resource "aws_kms_key" "main" {
  description             = "${var.project_name} ${var.environment} encryption key"
  deletion_window_in_days = 7
  enable_key_rotation    = true

  tags = {
    Name        = "${var.project_name}-${var.environment}-key"
    Environment = var.environment
  }
}

resource "aws_kms_alias" "main" {
  name          = "alias/${var.project_name}-${var.environment}"
  target_key_id = aws_kms_key.main.key_id
}
EOF

    cat << 'EOF' > infrastructure/terraform/modules/kms/variables.tf
variable "project_name" {
  description = "Name of the project"
  type        = string
}

variable "environment" {
  description = "Environment (dev/staging/prod)"
  type        = string
}
EOF

    cat << 'EOF' > infrastructure/terraform/modules/kms/outputs.tf
output "key_arn" {
  description = "ARN of the KMS key"
  value       = aws_kms_key.main.arn
}

output "key_id" {
  description = "ID of the KMS key"
  value       = aws_kms_key.main.key_id
}

output "key_alias" {
  description = "Alias of the KMS key"
  value       = aws_kms_alias.main.name
}
EOF
}


# Function to create ECR module
create_ecr_module() {
    cat << 'EOF' > infrastructure/terraform/modules/ecr/main.tf
resource "aws_ecr_repository" "repository" {
  for_each             = toset(var.repository_names)
  name                 = "${var.project_name}-${each.key}"
  image_tag_mutability = "MUTABLE"

  image_scanning_configuration {
    scan_on_push = true
  }

  encryption_configuration {
    encryption_type = "KMS"
    kms_key        = var.kms_key_arn
  }

  tags = {
    Name        = "${var.project_name}-${each.key}"
    Environment = var.environment
  }
}

resource "aws_ecr_lifecycle_policy" "policy" {
  for_each   = aws_ecr_repository.repository
  repository = each.value.name

  policy = jsonencode({
    rules = [{
      rulePriority = 1
      description  = "Keep last 30 images"
      selection = {
        tagStatus     = "any"
        countType     = "imageCountMoreThan"
        countNumber   = 30
      }
      action = {
        type = "expire"
      }
    }]
  })
}
EOF

    cat << 'EOF' > infrastructure/terraform/modules/ecr/variables.tf
variable "project_name" {
  description = "Name of the project"
  type        = string
}

variable "environment" {
  description = "Environment (dev/staging/prod)"
  type        = string
}

variable "repository_names" {
  description = "List of repository names to create"
  type        = list(string)
}

variable "kms_key_arn" {
  description = "ARN of KMS key for encryption"
  type        = string
}
EOF

    cat << 'EOF' > infrastructure/terraform/modules/ecr/outputs.tf
output "repository_urls" {
  description = "URLs of the created ECR repositories"
  value       = {
    for repo in aws_ecr_repository.repository :
    repo.name => repo.repository_url
  }
}

output "repository_arns" {
  description = "ARNs of the created ECR repositories"
  value       = {
    for repo in aws_ecr_repository.repository :
    repo.name => repo.arn
  }
}
EOF
}

# Function to create Secrets Manager module
create_secrets_module() {
    cat << 'EOF' > infrastructure/terraform/modules/secrets/main.tf
resource "aws_secretsmanager_secret" "secret" {
  for_each                = var.secrets
  name                    = "${var.project_name}/${var.environment}/${each.key}"
  description             = each.value.description
  kms_key_id             = var.kms_key_arn
  recovery_window_in_days = var.environment == "prod" ? 30 : 7

  tags = {
    Name        = "${var.project_name}-${each.key}"
    Environment = var.environment
  }
}

resource "aws_secretsmanager_secret_version" "secret_version" {
  for_each      = var.secrets
  secret_id     = aws_secretsmanager_secret.secret[each.key].id
  secret_string = jsonencode(each.value.value)
}

resource "aws_secretsmanager_secret_policy" "secret_policy" {
  for_each   = var.secrets
  secret_arn = aws_secretsmanager_secret.secret[each.key].arn

  policy = jsonencode({
    Version = "2012-10-17"
    Statement = [
      {
        Sid    = "EnableIAMUserPermissions"
        Effect = "Allow"
        Principal = {
          AWS = var.allowed_role_arns
        }
        Action = [
          "secretsmanager:GetSecretValue",
          "secretsmanager:DescribeSecret"
        ]
        Resource = "*"
      }
    ]
  })
}
EOF

    cat << 'EOF' > infrastructure/terraform/modules/secrets/variables.tf
variable "project_name" {
  description = "Name of the project"
  type        = string
}

variable "environment" {
  description = "Environment (dev/staging/prod)"
  type        = string
}

variable "secrets" {
  description = "Map of secrets to create"
  type = map(object({
    description = string
    value       = map(string)
  }))
}

variable "kms_key_arn" {
  description = "ARN of KMS key for encryption"
  type        = string
}

variable "allowed_role_arns" {
  description = "List of IAM role ARNs allowed to access the secrets"
  type        = list(string)
}
EOF

    cat << 'EOF' > infrastructure/terraform/modules/secrets/outputs.tf
output "secret_arns" {
  description = "ARNs of the created secrets"
  value       = {
    for key, secret in aws_secretsmanager_secret.secret :
    key => secret.arn
  }
}

output "secret_names" {
  description = "Names of the created secrets"
  value       = {
    for key, secret in aws_secretsmanager_secret.secret :
    key => secret.name
  }
}
EOF
}

# Execute the module creation functions
create_alb_module
create_kms_module
create_ecr_module
create_secrets_module

# Function to create Kubernetes base manifests
create_k8s_base_manifests() {
    # Frontend manifests
    cat << 'EOF' > k8s/base/frontend/deployment.yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: frontend
spec:
  replicas: 2
  selector:
    matchLabels:
      app: frontend
  template:
    metadata:
      labels:
        app: frontend
    spec:
      containers:
      - name: frontend
        image: ${ECR_REPOSITORY_PREFIX}-frontend:latest
        ports:
        - containerPort: 80
EOF

    cat << 'EOF' > k8s/base/frontend/service.yaml
apiVersion: v1
kind: Service
metadata:
  name: frontend
spec:
  type: ClusterIP
  ports:
  - port: 80
    targetPort: 80
  selector:
    app: frontend
EOF

    # Backend services manifests
    cat << 'EOF' > k8s/base/backend-services/deployment.yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: backend
spec:
  replicas: 3
  selector:
    matchLabels:
      app: backend
  template:
    metadata:
      labels:
        app: backend
    spec:
      containers:
      - name: backend
        image: ${ECR_REPOSITORY_PREFIX}-backend:latest
        ports:
        - containerPort: 8080
        env:
        - name: SPRING_PROFILES_ACTIVE
          value: ${DEPLOY_ENV}
EOF

    cat << 'EOF' > k8s/base/backend-services/service.yaml
apiVersion: v1
kind: Service
metadata:
  name: backend
spec:
  type: ClusterIP
  ports:
  - port: 8080
    targetPort: 8080
  selector:
    app: backend
EOF

    # Axon Server manifests
    cat << 'EOF' > k8s/base/axon-server/deployment.yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: axon-server
spec:
  replicas: 1
  selector:
    matchLabels:
      app: axon-server
  template:
    metadata:
      labels:
        app: axon-server
    spec:
      containers:
      - name: axon-server
        image: ${ECR_REPOSITORY_PREFIX}-axon-server:latest
        ports:
        - containerPort: 8024
        - containerPort: 8124
EOF

    cat << 'EOF' > k8s/base/axon-server/service.yaml
apiVersion: v1
kind: Service
metadata:
  name: axon-server
spec:
  type: ClusterIP
  ports:
  - name: gui
    port: 8024
    targetPort: 8024
  - name: grpc
    port: 8124
    targetPort: 8124
  selector:
    app: axon-server
EOF

    # Database manifests
    cat << 'EOF' > k8s/base/database/persistent-volume.yaml
apiVersion: v1
kind: PersistentVolumeClaim
metadata:
  name: database-pvc
spec:
  accessModes:
    - ReadWriteOnce
  resources:
    requests:
      storage: 20Gi
EOF
}

# Function to create Kubernetes overlay configurations
create_k8s_overlays() {
    # Dev environment
    cat << 'EOF' > k8s/overlays/dev/kustomization.yaml
apiVersion: kustomize.config.k8s.io/v1beta1
kind: Kustomization
bases:
  - ../../base/frontend
  - ../../base/backend-services
  - ../../base/axon-server
  - ../../base/database

namespace: dev

commonLabels:
  environment: dev
EOF

    # Staging environment
    cat << 'EOF' > k8s/overlays/staging/kustomization.yaml
apiVersion: kustomize.config.k8s.io/v1beta1
kind: Kustomization
bases:
  - ../../base/frontend
  - ../../base/backend-services
  - ../../base/axon-server
  - ../../base/database

namespace: staging

commonLabels:
  environment: staging
EOF

    # Production environment
    cat << 'EOF' > k8s/overlays/prod/kustomization.yaml
apiVersion: kustomize.config.k8s.io/v1beta1
kind: Kustomization
bases:
  - ../../base/frontend
  - ../../base/backend-services
  - ../../base/axon-server
  - ../../base/database

namespace: prod

commonLabels:
  environment: prod
EOF
}

# Function to create Docker configurations
create_docker_configs() {
    # Frontend Dockerfile
    cat << 'EOF' > docker/frontend/Dockerfile
FROM node:16-alpine as builder
WORKDIR /app
COPY package*.json ./
RUN npm install
COPY . .
RUN npm run build

FROM nginx:alpine
COPY --from=builder /app/build /usr/share/nginx/html
COPY nginx.conf /etc/nginx/conf.d/default.conf
EXPOSE 80
CMD ["nginx", "-g", "daemon off;"]
EOF

    # Backend Dockerfile
    cat << 'EOF' > docker/backend/Dockerfile
FROM amazoncorretto:17-alpine
WORKDIR /app
COPY target/*.jar app.jar
EXPOSE 8080
ENTRYPOINT ["java", "-jar", "app.jar"]
EOF

    # Axon Server Dockerfile
    cat << 'EOF' > docker/axon-server/Dockerfile
FROM openjdk:17-slim
WORKDIR /app
COPY axon-server.jar ./
EXPOSE 8024 8124
ENTRYPOINT ["java", "-jar", "axon-server.jar"]
EOF
}

# Execute the Kubernetes and Docker setup functions
create_k8s_base_manifests
create_k8s_overlays
create_docker_configs

# Function to create CI/CD configurations
create_cicd_configs() {
    # Create buildspec.yml for CodeBuild
    cat << 'EOF' > buildspec.yml
version: 0.2

phases:
  pre_build:
    commands:
      - echo Logging in to Amazon ECR...
      - aws ecr get-login-password --region ${AWS_REGION} | docker login --username AWS --password-stdin ${AWS_ACCOUNT_ID}.dkr.ecr.${AWS_REGION}.amazonaws.com
      - COMMIT_HASH=$(echo $CODEBUILD_RESOLVED_SOURCE_VERSION | cut -c 1-7)
      - IMAGE_TAG=${COMMIT_HASH:=latest}
  build:
    commands:
      - echo Build started on `date`
      - echo Building the Docker images...
      - docker build -t ${ECR_REPOSITORY_PREFIX}-frontend:${IMAGE_TAG} ./docker/frontend
      - docker build -t ${ECR_REPOSITORY_PREFIX}-backend:${IMAGE_TAG} ./docker/backend
      - docker build -t ${ECR_REPOSITORY_PREFIX}-axon-server:${IMAGE_TAG} ./docker/axon-server
  post_build:
    commands:
      - echo Build completed on `date`
      - echo Pushing the Docker images...
      - docker push ${ECR_REPOSITORY_PREFIX}-frontend:${IMAGE_TAG}
      - docker push ${ECR_REPOSITORY_PREFIX}-backend:${IMAGE_TAG}
      - docker push ${ECR_REPOSITORY_PREFIX}-axon-server:${IMAGE_TAG}
      - echo Writing image definitions file...
      - printf '{"ImageURI":"%s"}' ${ECR_REPOSITORY_PREFIX}-frontend:${IMAGE_TAG} > imageDefinitions.json
EOF

    # Create CodePipeline configuration
    cat << 'EOF' > deployment/pipeline.yml
Parameters:
  EnvironmentName:
    Type: String
    Default: dev
    AllowedValues: [dev, staging, prod]

Resources:
  ArtifactBucket:
    Type: AWS::S3::Bucket
    Properties:
      VersioningConfiguration:
        Status: Enabled
      EncryptionConfiguration:
        ServerSideEncryptionConfiguration:
          - ServerSideEncryptionByDefault:
              SSEAlgorithm: aws:kms

  Pipeline:
    Type: AWS::CodePipeline::Pipeline
    Properties:
      RoleArn: !GetAtt CodePipelineServiceRole.Arn
      ArtifactStore:
        Type: S3
        Location: !Ref ArtifactBucket
      Stages:
        - Name: Source
          Actions:
            - Name: Source
              ActionTypeId:
                Category: Source
                Owner: AWS
                Version: 1
                Provider: CodeCommit
              Configuration:
                RepositoryName: trading-platform
                BranchName: main
              OutputArtifacts:
                - Name: SourceCode
        - Name: Build
          Actions:
            - Name: Build
              ActionTypeId:
                Category: Build
                Owner: AWS
                Version: 1
                Provider: CodeBuild
              Configuration:
                ProjectName: !Ref BuildProject
              InputArtifacts:
                - Name: SourceCode
              OutputArtifacts:
                - Name: BuildOutput
        - Name: Deploy
          Actions:
            - Name: Deploy
              ActionTypeId:
                Category: Deploy
                Owner: AWS
                Version: 1
                Provider: ECS
              Configuration:
                ClusterName: !Sub ${EnvironmentName}-cluster
                ServiceName: frontend
                FileName: imageDefinitions.json
              InputArtifacts:
                - Name: BuildOutput
EOF
}

# Function to create monitoring configurations
create_monitoring_configs() {
    # Prometheus configuration
    cat << 'EOF' > monitoring/prometheus/prometheus.yml
global:
  scrape_interval: 15s
  evaluation_interval: 15s

rule_files:
  - "alert.rules"

alerting:
  alertmanagers:
  - static_configs:
    - targets:
      - "alertmanager:9093"

scrape_configs:
  - job_name: 'kubernetes-apiservers'
    kubernetes_sd_configs:
    - role: endpoints
    scheme: https
    tls_config:
      ca_file: /var/run/secrets/kubernetes.io/serviceaccount/ca.crt
    bearer_token_file: /var/run/secrets/kubernetes.io/serviceaccount/token
    relabel_configs:
    - source_labels: [__meta_kubernetes_namespace, __meta_kubernetes_service_name, __meta_kubernetes_endpoint_port_name]
      action: keep
      regex: default;kubernetes;https

  - job_name: 'kubernetes-nodes'
    scheme: https
    tls_config:
      ca_file: /var/run/secrets/kubernetes.io/serviceaccount/ca.crt
    bearer_token_file: /var/run/secrets/kubernetes.io/serviceaccount/token
    kubernetes_sd_configs:
    - role: node
    relabel_configs:
    - action: labelmap
      regex: __meta_kubernetes_node_label_(.+)
EOF

    # Grafana dashboards
    cat << 'EOF' > monitoring/grafana/datasources.yml
apiVersion: 1

datasources:
  - name: Prometheus
    type: prometheus
    access: proxy
    url: http://prometheus:9090
    isDefault: true
EOF

    # Create basic dashboard
    cat << 'EOF' > monitoring/grafana/dashboards/kubernetes-cluster.json
{
  "annotations": {
    "list": []
  },
  "editable": true,
  "gnetId": null,
  "graphTooltip": 0,
  "id": 1,
  "links": [],
  "panels": [
    {
      "datasource": "Prometheus",
      "fieldConfig": {
        "defaults": {
          "custom": {}
        }
      },
      "gridPos": {
        "h": 8,
        "w": 12,
        "x": 0,
        "y": 0
      },
      "id": 2,
      "title": "CPU Usage",
      "type": "graph"
    }
  ],
  "schemaVersion": 26,
  "style": "dark",
  "tags": [],
  "templating": {
    "list": []
  },
  "time": {
    "from": "now-6h",
    "to": "now"
  },
  "timepicker": {},
  "timezone": "",
  "title": "Kubernetes Cluster Monitoring",
  "uid": "k8s-cluster-monitoring",
  "version": 1
}
EOF

    # CloudWatch agent configuration
    cat << 'EOF' > monitoring/cloudwatch/agent-config.json
{
  "agent": {
    "metrics_collection_interval": 60,
    "run_as_user": "root"
  },
  "logs": {
    "logs_collected": {
      "files": {
        "collect_list": [
          {
            "file_path": "/var/log/containers/*.log",
            "log_group_name": "/aws/containerinsights/{cluster_name}/application",
            "log_stream_name": "{container_instance_id}"
          }
        ]
      }
    }
  },
  "metrics": {
    "metrics_collected": {
      "kubernetes": {
        "cluster_name": "${CLUSTER_NAME}",
        "metrics_collection_interval": 60
      }
    }
  }
}
EOF
}

# Execute the CI/CD and monitoring setup functions
create_cicd_configs
create_monitoring_configs

# Function to create security configurations
create_security_configs() {
    # Network policies for Kubernetes
    cat << 'EOF' > security/policies/network-policies.yaml
apiVersion: networking.k8s.io/v1
kind: NetworkPolicy
metadata:
  name: default-deny-all
spec:
  podSelector: {}
  policyTypes:
  - Ingress
  - Egress
---
apiVersion: networking.k8s.io/v1
kind: NetworkPolicy
metadata:
  name: allow-frontend-to-backend
spec:
  podSelector:
    matchLabels:
      app: backend
  policyTypes:
  - Ingress
  ingress:
  - from:
    - podSelector:
        matchLabels:
          app: frontend
    ports:
    - protocol: TCP
      port: 8080
EOF

    # RBAC configurations
    cat << 'EOF' > security/policies/rbac.yaml
apiVersion: rbac.authorization.k8s.io/v1
kind: ClusterRole
metadata:
  name: app-role
rules:
- apiGroups: [""]
  resources: ["pods", "services"]
  verbs: ["get", "list", "watch"]
---
apiVersion: rbac.authorization.k8s.io/v1
kind: ClusterRoleBinding
metadata:
  name: app-role-binding
subjects:
- kind: ServiceAccount
  name: app-service-account
  namespace: default
roleRef:
  kind: ClusterRole
  name: app-role
  apiGroup: rbac.authorization.k8s.io
EOF

    # SSL/TLS configuration
    cat << 'EOF' > security/certificates/certificate-config.yaml
apiVersion: cert-manager.io/v1
kind: Certificate
metadata:
  name: app-tls
spec:
  secretName: app-tls-secret
  duration: 2160h # 90 days
  renewBefore: 360h # 15 days
  subject:
    organizations:
      - ABC Trading Platform
  commonName: ${DOMAIN_NAME}
  dnsNames:
    - ${DOMAIN_NAME}
    - "*.${DOMAIN_NAME}"
  issuerRef:
    name: letsencrypt-prod
    kind: ClusterIssuer
EOF

    # IAM roles and policies
    cat << 'EOF' > security/policies/iam-policies.json
{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Effect": "Allow",
      "Action": [
        "ecr:GetAuthorizationToken",
        "ecr:BatchCheckLayerAvailability",
        "ecr:GetDownloadUrlForLayer",
        "ecr:BatchGetImage"
      ],
      "Resource": "*"
    },
    {
      "Effect": "Allow",
      "Action": [
        "secretsmanager:GetSecretValue",
        "secretsmanager:DescribeSecret"
      ],
      "Resource": [
        "arn:aws:secretsmanager:${AWS_REGION}:${AWS_ACCOUNT_ID}:secret:${PROJECT_NAME}/*"
      ]
    }
  ]
}
EOF
}

# Function to create documentation
create_documentation() {
    # Create runbook
    cat << 'EOF' > docs/runbooks/operations.md
# Operations Runbook

## Common Operations
1. Deploying Updates
   ./deploy.sh --environment [dev|staging|prod]

2. Scaling Services
   kubectl scale deployment frontend --replicas=3

3. Database Backup
   ./backup.sh --database trading

## Monitoring
1. Accessing Grafana
   - URL: https://grafana.${DOMAIN_NAME}
   - Default credentials in AWS Secrets Manager

2. Checking Logs
   - CloudWatch Logs
   - Kibana Dashboard

## Troubleshooting
1. Pod Crashes
   - Check logs: kubectl logs [pod-name]
   - Check events: kubectl describe pod [pod-name]

2. Database Issues
   - Check connectivity
   - Check RDS metrics
   - Review slow query logs
EOF

    # Create disaster recovery plan
    cat << 'EOF' > docs/disaster-recovery/dr-plan.md
# Disaster Recovery Plan

## Overview
This document outlines the disaster recovery procedures for the ABC Trading Platform.

## Recovery Point Objective (RPO)
- Production: 15 minutes
- Staging: 1 hour
- Development: 24 hours

## Recovery Time Objective (RTO)
- Production: 1 hour
- Staging: 4 hours
- Development: 24 hours

## Backup Procedures
1. Database Backups
   - Automated snapshots every 6 hours
   - Transaction logs backed up every 5 minutes
   - Cross-region replication enabled

2. Configuration Backups
   - Infrastructure as Code in version control
   - Regular exports of critical configurations

## Recovery Procedures
1. Database Recovery
   ./recover-db.sh --snapshot [snapshot-id] --target-instance [instance-name]

2. Application Recovery
   ./recover-app.sh --environment [env] --version [version]

3. Infrastructure Recovery
   ./recover-infrastructure.sh --region [region] --environment [env]

## Testing
- Monthly DR drills
- Quarterly full recovery testing
- Annual multi-region failover test
EOF
}

# Execute the security and documentation setup functions
create_security_configs
create_documentation

echo -e "${GREEN}Infrastructure setup completed successfully!${NC}"
echo -e "${YELLOW}Please review the generated configurations and update environment-specific values.${NC}"
