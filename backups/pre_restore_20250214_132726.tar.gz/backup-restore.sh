#!/bin/bash

# Color codes for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m'

# Default backup directory (create if it doesn't exist)
BACKUP_DIR="backups"
mkdir -p "${BACKUP_DIR}"

# Function to display usage
usage() {
    echo "Usage:"
    echo "  Backup:    $0 backup [backup-name]"
    echo "  Restore:   $0 restore [backup-name]"
    echo "  List:      $0 list"
    echo
    echo "If backup-name is not provided, the current timestamp will be used."
}

# Function to create backup
create_backup() {
    local backup_name=$1
    local timestamp=$(date +%Y%m%d_%H%M%S)
    
    # If no backup name provided, use timestamp
    if [ -z "$backup_name" ]; then
        backup_name="backup_${timestamp}"
    fi
    
    # Create backup directory
    local backup_path="${BACKUP_DIR}/${backup_name}"
    
    echo -e "${YELLOW}Creating backup: ${backup_name}${NC}"
    
    # Create tar archive excluding unnecessary directories and files
    tar --exclude="./backups" \
        --exclude="./node_modules" \
        --exclude="./.git" \
        --exclude="./target" \
        --exclude="./build" \
        --exclude="./dist" \
        -czf "${backup_path}.tar.gz" .
    
    if [ $? -eq 0 ]; then
        echo -e "${GREEN}Backup created successfully: ${backup_path}.tar.gz${NC}"
        echo -e "Size: $(du -h ${backup_path}.tar.gz | cut -f1)"
    else
        echo -e "${RED}Error creating backup${NC}"
        exit 1
    fi
}

# Function to restore backup
restore_backup() {
    local backup_name=$1
    
    if [ -z "$backup_name" ]; then
        echo -e "${RED}Error: Backup name must be provided for restore${NC}"
        usage
        exit 1
    fi
    
    local backup_file="${BACKUP_DIR}/${backup_name}.tar.gz"
    
    # Check if backup exists
    if [ ! -f "$backup_file" ]; then
        echo -e "${RED}Error: Backup file not found: ${backup_file}${NC}"
        exit 1
    fi
    
    # Create temporary directory for restoration
    local temp_dir=$(mktemp -d)
    
    echo -e "${YELLOW}Restoring backup: ${backup_name}${NC}"
    
    # Extract backup to temporary directory
    tar -xzf "$backup_file" -C "$temp_dir"
    
    if [ $? -eq 0 ]; then
        # Create backup of current state before restore
        local timestamp=$(date +%Y%m%d_%H%M%S)
        local pre_restore_backup="pre_restore_${timestamp}"
        echo -e "${YELLOW}Creating safety backup before restore: ${pre_restore_backup}${NC}"
        create_backup "$pre_restore_backup"
        
        # Copy files from temp directory to current directory
        echo -e "${YELLOW}Copying files from backup...${NC}"
        rsync -av --exclude="backups" "$temp_dir/" .
        
        if [ $? -eq 0 ]; then
            echo -e "${GREEN}Restore completed successfully${NC}"
            echo -e "${YELLOW}Pre-restore backup created: ${pre_restore_backup}${NC}"
        else
            echo -e "${RED}Error during restore${NC}"
            exit 1
        fi
    else
        echo -e "${RED}Error extracting backup${NC}"
        exit 1
    fi
    
    # Cleanup
    rm -rf "$temp_dir"
}

# Function to list backups
list_backups() {
    echo -e "${YELLOW}Available backups:${NC}"
    if [ -d "$BACKUP_DIR" ]; then
        if [ -n "$(ls -A ${BACKUP_DIR}/*.tar.gz 2>/dev/null)" ]; then
            for backup in ${BACKUP_DIR}/*.tar.gz; do
                echo -e "${GREEN}$(basename "$backup" .tar.gz)${NC}"
                echo "  Size: $(du -h "$backup" | cut -f1)"
                echo "  Created: $(date -r "$backup" "+%Y-%m-%d %H:%M:%S")"
            done
        else
            echo "No backups found"
        fi
    else
        echo "Backup directory does not exist"
    fi
}

# Main script logic
case "$1" in
    backup)
        create_backup "$2"
        ;;
    restore)
        restore_backup "$2"
        ;;
    list)
        list_backups
        ;;
    *)
        usage
        exit 1
        ;;
esac

exit 0
