#!/bin/bash

set -e

# Color codes for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m'

# Get script directory for relative paths
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
BASE_DIR="$(cd "${SCRIPT_DIR}/.." && pwd)"
CONFIG_DIR="${BASE_DIR}/config"
K8S_DIR="${BASE_DIR}/k8s"

# Load environment variables
if [ -z "$ENV_FILE" ]; then
    echo -e "${RED}Error: ENV_FILE not set${NC}"
    exit 1
fi

source "$ENV_FILE"

# Update Kubernetes configs
update_k8s_configs() {
    echo -e "${YELLOW}Updating Kubernetes configurations...${NC}"
    
    # Update Kubernetes secrets
    kubectl create secret generic app-secrets \
        --from-literal=DB_PASSWORD="${DB_PASSWORD}" \
        --from-literal=API_KEY="${API_KEY}" \
        -n "${DEPLOY_ENV}" \
        --dry-run=client -o yaml | kubectl apply -f -
    
    # Update ConfigMaps
    kubectl create configmap app-config \
        --from-file="${CONFIG_DIR}/application.yaml" \
        -n "${DEPLOY_ENV}" \
        --dry-run=client -o yaml | kubectl apply -f -
}

# Deploy applications
deploy_applications() {
    echo -e "${YELLOW}Deploying applications...${NC}"
    
    # Apply Kubernetes manifests
    kubectl apply -k "${K8S_DIR}/overlays/${DEPLOY_ENV}"
    
    # Wait for rollout completion
    for deployment in $(kubectl get deployments -n "${DEPLOY_ENV}" -o name); do
        kubectl rollout status "${deployment}" -n "${DEPLOY_ENV}" --timeout=300s
    done
}

# Setup ingress
setup_ingress() {
    echo -e "${YELLOW}Setting up ingress...${NC}"
    
    # Apply ingress configuration
    kubectl apply -f "${K8S_DIR}/overlays/${DEPLOY_ENV}/ingress.yaml"
    
    # Wait for ALB provisioning
    sleep 30
    
    # Get ALB DNS name
    ALB_DNS=$(kubectl get ingress -n "${DEPLOY_ENV}" -o jsonpath='{.items[0].status.loadBalancer.ingress[0].hostname}')
    
    if [ -n "${DOMAIN_NAME}" ] && [ -n "${HOSTED_ZONE_ID}" ]; then
        aws route53 change-resource-record-sets \
            --hosted-zone-id "${HOSTED_ZONE_ID}" \
            --change-batch "{
                \"Changes\": [{
                    \"Action\": \"UPSERT\",
                    \"ResourceRecordSet\": {
                        \"Name\": \"${DEPLOY_ENV}.${DOMAIN_NAME}\",
                        \"Type\": \"CNAME\",
                        \"TTL\": 300,
                        \"ResourceRecords\": [{
                            \"Value\": \"${ALB_DNS}\"
                        }]
                    }
                }]
            }"
        echo -e "${GREEN}DNS record updated for ${DEPLOY_ENV}.${DOMAIN_NAME}${NC}"
    else
        echo -e "${YELLOW}No domain name or hosted zone provided. Using EKS endpoint.${NC}"
        echo -e "${GREEN}Application will be available at: ${ALB_DNS}${NC}"
    fi
}

# Health checks
perform_health_checks() {
    echo -e "${YELLOW}Performing health checks...${NC}"
    
    # Wait for services to be ready
    sleep 30
    
    # Get the service endpoint
    SERVICE_ENDPOINT=$(kubectl get ingress -n "${DEPLOY_ENV}" -o jsonpath='{.items[0].status.loadBalancer.ingress[0].hostname}')
    
    # Check each service's health endpoint
    for service in ${MICROSERVICES}; do
        HEALTH_URL="http://${SERVICE_ENDPOINT}/api/${service}/health"
        echo -e "${YELLOW}Checking health for ${service} at ${HEALTH_URL}${NC}"
        curl -sf "${HEALTH_URL}" || {
            echo -e "${RED}Health check failed for ${service}${NC}"
            exit 1
        }
        echo -e "${GREEN}Health check passed for ${service}${NC}"
    done
}

# Rollback procedure
rollback() {
    echo -e "${RED}Deployment failed, initiating rollback...${NC}"
    
    # Rollback to previous version
    kubectl rollout undo deployment -n "${DEPLOY_ENV}" --all
    
    # Wait for rollback completion
    for deployment in $(kubectl get deployments -n "${DEPLOY_ENV}" -o name); do
        kubectl rollout status "${deployment}" -n "${DEPLOY_ENV}" --timeout=300s
    done
    
    echo -e "${YELLOW}Rollback completed${NC}"
    exit 1
}

# Validate deployment
validate_deployment() {
    echo -e "${YELLOW}Validating deployment...${NC}"
    
    # Check pod status
    FAILED_PODS=$(kubectl get pods -n "${DEPLOY_ENV}" --field-selector status.phase!=Running,status.phase!=Succeeded -o name)
    if [ -n "${FAILED_PODS}" ]; then
        echo -e "${RED}Failed pods detected${NC}"
        echo "${FAILED_PODS}"
        rollback
    fi
    
    echo -e "${GREEN}Deployment validation completed${NC}"
}

# Main execution
main() {
    update_k8s_configs
    deploy_applications
    setup_ingress
    perform_health_checks
    validate_deployment
}

# Trap errors
trap 'rollback' ERR

main
