#!/bin/bash

set -e

# Color codes for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m'

# Check if environment parameter is provided
if [ -z "$1" ]; then
    echo -e "${RED}Error: Environment parameter is required (dev|staging|prod)${NC}"
    exit 1
fi

DEPLOY_ENV="$1"

# Store original directory and script locations
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ENV_FILE="${SCRIPT_DIR}/.env"

# Load environment variables
if [ ! -f "$ENV_FILE" ]; then
    echo -e "${RED}Error: .env file not found at ${ENV_FILE}. Run setup.sh first.${NC}"
    exit 1
fi

source "$ENV_FILE"

# Update paths to use infrastructure directory
TERRAFORM_DIR="${SCRIPT_DIR}/infrastructure/terraform"
ENV_DIR="${TERRAFORM_DIR}/environments/${DEPLOY_ENV}"

# Verify Terraform files exist
verify_terraform_files() {
    echo -e "${YELLOW}Verifying Terraform configuration...${NC}"
    
    required_files=("main.tf" "variables.tf" "terraform.tfvars")
    for file in "${required_files[@]}"; do
        if [ ! -f "${ENV_DIR}/${file}" ]; then
            echo -e "${RED}Error: Required Terraform file ${ENV_DIR}/${file} not found${NC}"
            echo -e "${YELLOW}Run setup.sh to create the required Terraform configuration files${NC}"
            exit 1
        fi
    done
    
    # Verify networking module files
    module_dir="${TERRAFORM_DIR}/modules/networking"
    module_files=("main.tf" "variables.tf" "outputs.tf")
    for file in "${module_files[@]}"; do
        if [ ! -f "${module_dir}/${file}" ]; then
            echo -e "${RED}Error: Required module file ${module_dir}/${file} not found${NC}"
            echo -e "${YELLOW}Run setup.sh to create the required Terraform module files${NC}"
            exit 1
        fi
    done
}

# Create S3 bucket for Terraform state
create_terraform_state_bucket() {
    echo -e "${YELLOW}Checking Terraform state bucket...${NC}"
    
    if [ -z "${TF_STATE_BUCKET}" ]; then
        echo -e "${RED}Error: TF_STATE_BUCKET not set in .env file${NC}"
        exit 1
    fi
    
    if [ -z "${AWS_REGION}" ]; then
        echo -e "${RED}Error: AWS_REGION not set in .env file${NC}"
        exit 1
    fi
    
    # Check if bucket exists
    if ! aws s3 ls "s3://${TF_STATE_BUCKET}" 2>&1 > /dev/null; then
        echo -e "${YELLOW}Creating Terraform state bucket: ${TF_STATE_BUCKET}${NC}"
        
        # Create bucket with versioning enabled
        if [ "${AWS_REGION}" = "us-east-1" ]; then
            aws s3api create-bucket \
                --bucket "${TF_STATE_BUCKET}" \
                --region "${AWS_REGION}"
        else
            aws s3api create-bucket \
                --bucket "${TF_STATE_BUCKET}" \
                --region "${AWS_REGION}" \
                --create-bucket-configuration LocationConstraint="${AWS_REGION}"
        fi
        
        # Enable versioning
        aws s3api put-bucket-versioning \
            --bucket "${TF_STATE_BUCKET}" \
            --versioning-configuration Status=Enabled
            
        # Enable server-side encryption
        aws s3api put-bucket-encryption \
            --bucket "${TF_STATE_BUCKET}" \
            --server-side-encryption-configuration '{
                "Rules": [
                    {
                        "ApplyServerSideEncryptionByDefault": {
                            "SSEAlgorithm": "AES256"
                        }
                    }
                ]
            }'
            
        # Block public access
        aws s3api put-public-access-block \
            --bucket "${TF_STATE_BUCKET}" \
            --public-access-block-configuration '{
                "BlockPublicAcls": true,
                "IgnorePublicAcls": true,
                "BlockPublicPolicy": true,
                "RestrictPublicBuckets": true
            }'
            
        echo -e "${GREEN}Terraform state bucket created successfully${NC}"
    else
        echo -e "${GREEN}Terraform state bucket already exists${NC}"
    fi
}

# Initialize and apply network infrastructure
deploy_network() {
    echo -e "${YELLOW}Deploying network infrastructure...${NC}"
    
    # Verify required environment variables
    if [ -z "${TF_STATE_BUCKET}" ]; then
        echo -e "${RED}Error: TF_STATE_BUCKET not set in .env file${NC}"
        exit 1
    fi
    
    cd "${ENV_DIR}"
    
    # Initialize Terraform
    terraform init \
        -backend-config="bucket=${TF_STATE_BUCKET}" \
        -backend-config="key=${DEPLOY_ENV}/network/terraform.tfstate" \
        -backend-config="region=${AWS_REGION}"
    
    # Plan and apply network infrastructure
    terraform plan -target=module.networking -out=network.tfplan
    terraform apply network.tfplan
    
    cd "${SCRIPT_DIR}"
    
    echo -e "${GREEN}Network infrastructure deployed successfully${NC}"
}

# Validate network configuration
validate_network() {
    echo -e "${YELLOW}Validating network configuration...${NC}"
    
    # Check VPC creation
    VPC_ID=$(aws ec2 describe-vpcs \
        --filters "Name=tag:Environment,Values=${DEPLOY_ENV}" \
        --query 'Vpcs[0].VpcId' --output text)
    
    if [ "$VPC_ID" == "None" ]; then
        echo -e "${RED}Error: VPC not found${NC}"
        exit 1
    fi
    
    echo -e "${GREEN}Network validation completed${NC}"
}

# Execute additional scripts
execute_script() {
    local script_path="$1"
    local script_full_path="${SCRIPT_DIR}/${script_path}"
    
    if [ -f "$script_full_path" ]; then
        echo -e "${YELLOW}Executing: ${script_path}${NC}"
        ENV_FILE="$ENV_FILE" bash "$script_full_path" "$DEPLOY_ENV"
        if [ $? -eq 0 ]; then
            echo -e "${GREEN}Successfully executed: ${script_path}${NC}"
        else
            echo -e "${RED}Failed to execute: ${script_path}${NC}"
            exit 1
        fi
    else
        echo -e "${YELLOW}Script not found (skipping): ${script_path}${NC}"
    fi
}

# Main execution
main() {
    # Verify terraform directory structure exists
    if [ ! -d "${TERRAFORM_DIR}" ]; then
        echo -e "${RED}Error: Terraform directory not found${NC}"
        echo -e "${YELLOW}Run setup.sh first to create the required directory structure${NC}"
        exit 1
    fi

    verify_terraform_files
    create_terraform_state_bucket
    deploy_network
    validate_network
    
    # Execute additional infrastructure scripts
    execute_script "infrastructure/eks.sh"
    execute_script "infrastructure/database.sh"
    
    # Execute security scripts
    execute_script "security/certificates.sh"
    execute_script "security/security.sh"
    
    # Execute monitoring scripts
    execute_script "monitoring/cloudwatch.sh"
    execute_script "monitoring/logging.sh"
    
    # Execute deployment scripts
    execute_script "deployment/build.sh"
    execute_script "deployment/deploy.sh"
    
    echo -e "${GREEN}Deployment completed successfully${NC}"
}

main
