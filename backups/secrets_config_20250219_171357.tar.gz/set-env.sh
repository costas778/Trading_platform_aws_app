#!/bin/bash
# AWS credentials
export AWS_ACCESS_KEY_ID="AKIATCKAM56GYXFIHMWG"
export AWS_SECRET_ACCESS_KEY="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"
export AWS_DEFAULT_REGION="us-east-1"

# Sensitive variables
export TF_VAR_database_password="Harvee777"

# Application runtime configuration
export BUILD_VERSION="1.0.0"
export DOMAIN_NAME="abc-trading-dev.com"
export HOSTED_ZONE_ID="Z06837973EPZKAJ7CZ8HV"

# Infrastructure configuration
export TF_STATE_BUCKET="bucket211125333901"
export TF_LOCK_TABLE="terraform-state-lock"
export CLUSTER_NAME="abc-trading-dev"
export MICROSERVICES="axon-server backend-services frontend"